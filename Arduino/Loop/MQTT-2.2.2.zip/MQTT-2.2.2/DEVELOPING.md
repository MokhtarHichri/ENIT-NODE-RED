# Developing

- Update version in `library.properties`.
- Create release on GitHub.
